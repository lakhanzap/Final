jQuery(document).ready(function($){
        $(".club-results-table").tablesorter();
        $(".club-schedule-table").tablesorter();

        jQuery(".club-results-table tr").mouseover(function(){
                jQuery(this).addClass("over");
        });
        jQuery(".club-results-table tr").mouseout(function(){
                jQuery(this).removeClass("over");
        });
        jQuery(".club-schedule-table tr").mouseover(function(){
        	jQuery(this).addClass("over");
	});
        jQuery(".club-schedule-table tr").mouseout(function(){
        	jQuery(this).removeClass("over");
	});
});
function showTab( toShow ) {
        jQuery(".tabContent").hide();
        jQuery(toShow).show();

}
